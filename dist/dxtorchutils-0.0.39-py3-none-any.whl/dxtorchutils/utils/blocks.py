from torch.nn import *
from collections import OrderedDict
import torch
from dxtorchutils.utils.layers import *


class SeConvBNReLU(Module):
    def __init__(self, channels, reduction=16):
        super(SeConvBNReLU, self).__init__()

        self.channels = channels
        mid_channel = channels // reduction if channels // reduction > 0 else 1

        self.pool = AdaptiveAvgPool2d(1)
        self.fc0 = fc_relu(channels, mid_channel, False)
        self.fc1 = fc_sigmoid(mid_channel, channels, False)

    def forward(self, input):
        batch_size, channels, _, _ = input.shape
        assert channels == self.channels, "Channel mismatch"

        x = self.pool(input)
        x = x.view(batch_size, channels)
        x = self.fc0(x)
        x = self.fc1(x)
        attention = x.view(batch_size, channels, 1, 1)

        output = input * attention

        return output
