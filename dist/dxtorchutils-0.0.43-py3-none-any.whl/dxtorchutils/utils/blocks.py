from torch.nn import *
from collections import OrderedDict
import torch
from dxtorchutils.utils.layers import *


class SeBlock(Module):
    def __init__(self, channels, reduction=16):
        super(SeBlock, self).__init__()

        self.channels = channels
        mid_channel = channels // reduction if channels // reduction > 0 else 1

        self.pool = AdaptiveAvgPool2d(1)
        self.fc0 = fc_relu(channels, mid_channel, False)
        self.fc1 = fc_sigmoid(mid_channel, channels, False)

    def forward(self, input):
        batch_size, channels, _, _ = input.shape
        assert channels == self.channels, "Channel mismatch"

        x = self.pool(input)
        x = x.view(batch_size, channels)
        x = self.fc0(x)
        x = self.fc1(x)
        attention = x.view(batch_size, channels, 1, 1)

        output = input * attention

        return output


import torch
from torch import nn
from torch.nn import functional as F


class _NonLocalBlockND(nn.Module):
    """
    调用过程
    NONLocalBlock2D(in_channels=32),
    super(NONLocalBlock2D, self).__init__(in_channels,
            inter_channels=inter_channels,
            dimension=2, sub_sample=sub_sample,
            bn_layer=bn_layer)
    """

    def __init__(self,
                 in_channels,
                 inter_channels=None,
                 dimension=3,
                 sub_sample=True,
                 bn_layer=True):
        super(_NonLocalBlockND, self).__init__()

        assert dimension in [1, 2, 3]

        self.dimension = dimension
        self.sub_sample = sub_sample

        self.in_channels = in_channels
        self.inter_channels = inter_channels

        if self.inter_channels is None:
            self.inter_channels = in_channels // 2
            # 进行压缩得到channel个数
            if self.inter_channels == 0:
                self.inter_channels = 1

        max_pool_layer = nn.MaxPool2d(2)

        self.g = Conv2d(in_channels=self.in_channels,
                        out_channels=self.inter_channels,
                        kernel_size=1,
                        stride=1,
                        padding=0)

        self.W = nn.Sequential(
            Conv2d(in_channels=self.inter_channels,
                   out_channels=self.in_channels,
                   kernel_size=1,
                   stride=1,
                   padding=0), BatchNorm2d(self.in_channels))

        nn.init.constant_(self.W[1].weight, 0)
        nn.init.constant_(self.W[1].bias, 0)

        self.theta = Conv2d(in_channels=self.in_channels,
                            out_channels=self.inter_channels,
                            kernel_size=1,
                            stride=1,
                            padding=0)
        self.phi = Conv2d(in_channels=self.in_channels,
                          out_channels=self.inter_channels,
                          kernel_size=1,
                          stride=1,
                          padding=0)

        if sub_sample:
            self.g = nn.Sequential(self.g, max_pool_layer)
            self.phi = nn.Sequential(self.phi, max_pool_layer)

    def forward(self, x):
        '''
        :param x: (b, c,  h, w)
        :return:
        '''

        batch_size = x.size(0)

        g_x = self.g(x).view(batch_size, self.inter_channels, -1)  # [bs, c, w*h]
        g_x = g_x.permute(0, 2, 1)

        theta_x = self.theta(x).view(batch_size, self.inter_channels, -1)
        theta_x = theta_x.permute(0, 2, 1)

        phi_x = self.phi(x).view(batch_size, self.inter_channels, -1)

        f = torch.matmul(theta_x, phi_x)

        print(f.shape)

        f_div_C = F.softmax(f, dim=-1)

        y = torch.matmul(f_div_C, g_x)
        y = y.permute(0, 2, 1).contiguous()
        y = y.view(batch_size, self.inter_channels, *x.size()[2:])
        W_y = self.W(y)
        z = W_y + x
        return z
