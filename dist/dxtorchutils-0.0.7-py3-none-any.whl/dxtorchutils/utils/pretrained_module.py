import requests
import torch
import os
import dxtorchutils
from .utils import state_logger


class Module(torch.nn.Module):
    def load_pretrained_model(self):
        pretrained_model_path = dxtorchutils.__file__[:-11] + "pretrained_models/{}.pth".format(self.__class__.__name__.lower())
        if not os.path.isfile(pretrained_model_path):
            state_logger("Downloading pretrained model!")
            r = requests.get(
                "https://raw.githubusercontent.com/Ian-Dx/PretrainedModels/main/{}.pth".format(self.__class__.__name__.lower()))
            with open(pretrained_model_path, "w") as f:
                f.write(r.content)

        self.load_state_dict(torch.load(pretrained_model_path))
        state_logger("Pretrained model loaded!")

