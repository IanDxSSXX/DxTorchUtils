from dxtorchutils.SemanticSegmentation.models import *
import torch
import time

a = UNet()
b = MobileUNet()

x = torch.randn((2,3,500,500))

t1 = time.time()
a(x)
t2 = time.time()
b(x)
t3 = time.time()

print((t2-t1) * 1000)
print((t3-t2) * 1000)
