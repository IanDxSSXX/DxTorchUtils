import torch
import torch.nn as nn
from sklearn.metrics import confusion_matrix

from Dataset import SemanticSegDataset
from torch_utils.models import *
import cv2
from torch.utils.data import TensorDataset, DataLoader
from Validate import validate
import numpy as np
from torch_utils.utils.HTMLGene import *



# def eval_iou(target, prediction):
#     TN, FP, FN, TP = confusion_matrix(
#         y_true=np.array(target).flatten(),
#         y_pred=np.array(prediction).flatten(),
#         labels=[0, 1]
#     ).ravel()
#
#     iou = TP / (FP + TP + FN)
#
#     return iou
#
#
# def eval_dice(target, prediction):
#     TN, FP, FN, TP = confusion_matrix(
#         y_true=np.array(target).flatten(),
#         y_pred=np.array(prediction).flatten(),
#         labels=[0, 1]
#     ).ravel()
#
#     dice = 2 * TP / (FP + 2 * TP + FN)
#
#
#     return dice
#
#
# paras = RenderParas(
#     dir_path="results",
#     title="Iris Segmentation",
#     description="Iris Segmentation Using DenseASPP",
#     training_num=1750,
#     validation_num=300,
#     testing_num=200,
#     metrics=["IoU", "Dice"]
# )
# deeplabv3_paras = ModelParas(
#     model_name="DeeplabV3",
#     paper_url="https://arxiv.org/pdf/1706.05587.pdf",
#     paper_name="Rethinking atrous convolution for semantic image segmentation",
#     code_url="https://github.com/Ian-Dx/NNModels/blob/master/Dx-torchutils/DeeplabV3.py"
# )
# model = DeeplabV3(2)
# data = cv2.imread("/Users/iandx/Documents/Documents/Files/DeepfakeDetection/IrisSegmentation/src/resources/data/testing/iris_raw/C97_S1_I11.tiff")
# label = cv2.imread("/Users/iandx/Documents/Documents/Files/DeepfakeDetection/IrisSegmentation/src/resources/data/testing/iris_ground_truth/C97_S1_I11_gt.png", 0)
# data = np.transpose(data, (2, 0, 1))
# data = (torch.from_numpy(data) / 255).type(torch.FloatTensor)
# data = torch.unsqueeze(data, 0)
#
# label = (torch.from_numpy(label) / 255).type(torch.LongTensor)
# label = torch.unsqueeze(label, 0)
#
# dataset = TensorDataset(data, label)
#
# dl = DataLoader(dataset, 1)
#
# validate(dl, model, [[0,0,0], [0,0,255]],[["iou",eval_iou],["dice",eval_dice]],model_paras=deeplabv3_paras)
#
#


