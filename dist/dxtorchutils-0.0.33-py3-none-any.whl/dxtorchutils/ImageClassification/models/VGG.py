"""VGG"""
from collections import OrderedDict
from torch.nn import *


class VGG11(Module):
    def __init__(self):
        super(VGG11, self).__init__()
        self.conv = _conv_layer(1, 1, 2, 2, 2)
        self.fc = Sequential(
            OrderedDict([
                ("fc1", _fc_relu(25088, 4096)),
                ("fc2", _fc_relu(4096, 4096))
            ])
        )
        self.out = Linear(4096, 1000)


    def forward(self, input):
        # (n, 3, 224, 224)
        x = self.conv(input)
        # (n, 512, 7, 7)
        x = x.view(x.shape[0], -1)
        # (n, 25088)
        x = self.fc(x)
        # (n, 4096)
        output = self.out(x)
        # (n, 1000)

        return output


class VGG13(Module):
    def __init__(self=True):
        super(VGG13, self).__init__()
        self.conv = _conv_layer(2, 2, 2, 2, 2)
        self.fc = Sequential(
            OrderedDict([
                ("fc1", _fc_relu(25088, 4096)),
                ("fc2", _fc_relu(4096, 4096))
            ])
        )
        self.out = Linear(4096, 1000)


    def forward(self, input):
        # (n, 3, 224, 224)
        x = self.conv(input)
        # (n, 512, 7, 7)
        x = x.view(x.shape[0], -1)
        # (n, 25088)
        x = self.fc(x)
        # (n, 4096)
        output = self.out(x)
        # (n, 1000)

        return output


class VGG16(Module):
    def __init__(self=True):
        super(VGG16, self).__init__()
        self.conv = _conv_layer(2, 2, 3, 3, 3)
        self.fc = Sequential(
            OrderedDict([
                ("fc1", _fc_relu(25088, 4096)),
                ("fc2", _fc_relu(4096, 4096))
            ])
        )
        self.out = Linear(4096, 1000)


    def forward(self, input):
        # (n, 3, 224, 224)
        x = self.conv(input)
        # (n, 512, 7, 7)
        x = x.view(x.shape[0], -1)
        # (n, 25088)
        x = self.fc(x)
        # (n, 4096)
        output = self.out(x)
        # (n, 1000)

        return output


class VGG19(Module):
    def __init__(self=True):
        super(VGG19, self).__init__()
        self.conv = _conv_layer(2, 2, 4, 4, 4)
        self.fc = Sequential(
            OrderedDict([
                ("fc1", _fc_relu(25088, 4096)),
                ("fc2", _fc_relu(4096, 4096))
            ])
        )
        self.out = Linear(4096, 1000)


    def forward(self, input):
        # (n, 3, 224, 224)
        x = self.conv(input)
        # (n, 512, 7, 7)
        x = x.view(x.shape[0], -1)
        # (n, 25088)
        x = self.fc(x)
        # (n, 4096)
        output = self.out(x)
        # (n, 1000)

        return output


def _conv_layer(num1, num2, num3, num4, num5):
    return Sequential(
        OrderedDict([
            ("conv0", _Conv(3, 64, num1)),
            ("conv1", _Conv(64, 128, num2)),
            ("conv2", _Conv(128, 256, num3)),
            ("conv3", _Conv(256, 512, num4)),
            ("conv4", _Conv(512, 512, num5))
        ])
    )


class _Conv(Module):
    def __init__(self, in_channels, out_channels, layer_num):
        super(_Conv, self).__init__()
        self.convs = Sequential()
        self.convs.add_module("conv0", _conv_relu_bn(in_channels, out_channels, 3, 1, 1))

        for i in range(layer_num - 1):
            self.convs.add_module("conv{}".format(i + 1), _conv_relu_bn(out_channels, out_channels, 3, 1, 1))

        self.pool = MaxPool2d(2)

    def forward(self, input):
        x = input
        
        x = self.convs(x)

        output = self.pool(x)

        return output


def _conv_relu_bn(in_channels, out_channels, kernel_size, stride=1, padding=0):
    return Sequential(
        OrderedDict([
            ("conv", Conv2d(in_channels, out_channels, kernel_size, stride, padding)),
            ("activation", ReLU(True)),
            ("normalization", BatchNorm2d(out_channels))
        ])
    )


def _fc_relu(in_features, out_features):
    return Sequential(
        OrderedDict([
            ("fc", Linear(in_features, out_features)),
            ("activation", ReLU(True)),
        ])
    )
