import os
import function
from torch.utils import data
import cv2
import torch
import numpy as np
from Others import state_logger


class SemanticSegDataset(data.Dataset):
    def __init__(
        self, dataset_dir_path: str,
            dataset_type: str,
            raw_path: str = "raw",
            label_path: str = "label",
            raw_suffix: str = "png",
            label_suffix: str = "png",
            raw_name_format: str = "{}",
            label_name_format: str = "{}"
    ):
        super(SemanticSegDataset, self).__init__()
        assert dataset_type == "training" or "validation" or "testing", "Wrong dataset type!"


        if dataset_dir_path.endswith("/"):
            dataset_path = dataset_dir_path + dataset_type
        else:
            dataset_path = dataset_dir_path + "/" + dataset_type

        self.raw_dataset_path = dataset_path + "/" + raw_path + "/"
        self.label_dataset_path = dataset_path + "/" + label_path + "/"

        self.raw_head = raw_name_format.split("{")[0]
        self.raw_tail = raw_name_format.split("{")[-1].split("}")[-1]
        self.label_head = label_name_format.split("{")[0]
        self.label_tail = label_name_format.split("{")[-1].split("}")[-1]
        self.raw_suffix = "." + raw_suffix
        self.label_suffix = "." + label_suffix

        raw_names = os.listdir(self.raw_dataset_path)
        label_names = os.listdir(self.label_dataset_path)

        self.image_id = []
        for raw_name in raw_names:
            if raw_name.endswith(self.raw_suffix) and raw_name[0] != ".":
                raw_id = raw_name.strip(self.raw_head).strip(self.raw_tail).strip(self.raw_suffix)
                label_name = self.label_head + raw_id + self.label_tail + self.label_suffix
                if label_name in label_names:
                    self.image_id.append(raw_id)

        # 拿到color map
        label_path = self.label_dataset_path + self.label_head + self.image_id[0] + self.label_tail + self.label_suffix
        self.color_map = get_color_map(label_path)

    def __len__(self):
        return len(self.image_id)


    def __getitem__(self, index):
        data = []
        target = []

        for image_id in self.image_id[index]:
            raw_path = self.raw_dataset_path + self.raw_head + image_id + self.raw_tail + self.raw_suffix
            label_path = self.label_dataset_path + self.label_head + image_id + self.label_tail + self.label_suffix

            raw_image = cv2.imread(raw_path)
            label_image = cv2.imread(label_path)

            if len(raw_image.shape) == 3:
                raw_image = raw_image.transpose(2, 0, 1)

            target_image = np.zeros(label_image.shape[:2])

            # 注意-1的操作，这样加快很多
            for idx, color in enumerate(self.color_map):
                target_image = np.where((label_image == color).all(axis=-1), idx, 0)

            data.append(raw_image)
            target.append(target_image)

        data = torch.from_numpy(np.array(data)).type(torch.FloatTensor)
        target = torch.from_numpy(np.array(target)).type(torch.LongTensor)

        state_logger("Dataset Prepared!")
        return data, target




def get_color_map(label_path):
    image = cv2.imread(label_path)
    image = np.reshape(image, (-1, 3))
    image_tuple = [tuple(bgr) for bgr in image]
    color_map = set(image_tuple)

    return color_map


# print(get_color_map("/Users/iandx/Documents/Documents/Files/DeepfakeDetection/IrisSegmentation/src/resources/data/testing/iris_ground_truth/C97_S1_I11_gt.png"))

ds = SemanticSegDataset(
    dataset_dir_path="/Users/iandx/Documents/Documents/Files/DeepfakeDetection/IrisSegmentation/src/resources/data",
    dataset_type="testing",
    raw_path="iris_raw",
    label_path="iris_ground_truth",
    raw_name_format="{}",
    label_name_format="{}_gt",
    raw_suffix="tiff"

)


print(ds[:][0].shape)
