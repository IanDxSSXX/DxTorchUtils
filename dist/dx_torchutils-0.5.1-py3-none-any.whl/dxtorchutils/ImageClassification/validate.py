import function
from torch.utils.data import DataLoader
import numpy as np
from ..utils.utils import state_logger
import torch




# class ValidataVessel:
#     def __init__(self,
#                  dataloader: DataLoader,
#                  model: torch.nn.Module,
#                  model_paras_path: str,
#                  eval_criteria: [[str, function]],
#                  is_gpu: bool = False,
#                  ):

def validate(
        dataloader: DataLoader,
        model: torch.nn.Module,
        model_paras_path: str,
        eval_criteria: [[str, function]],
        is_gpu: bool = False,
):
    """
    语义分割测试
    :param dataloader: 需要测试的dataloader
    :param model: 需要测试的空模型
    :param model_paras_path: 训练好的参数的地址，用来测试
    :param eval_criteria: 测试所需要的评价标准和对应的名字的数组，第一个是名字，第二个输入为（标签，预测），输出为小数的准确率
    :param is_gpu: 是否使用gpu，默认为false
    :return:
    """

    model.load_state_dict(torch.load(model_paras_path))
    if is_gpu:
        model.cuda()

    model.eval()

    state_logger("Model and Dataset Loaded, Start to Validate!")

    idx = 0
    with torch.no_grad():
        for val_data, val_target in dataloader:
            for data, targets in zip(val_data, val_target):
                if is_gpu:
                    data = data.cuda()
                    targets = targets.cuda()


                # 这里的每个数据都是单个
                data = torch.unsqueeze(data, 0)
                output = model(data)

                # reshape成图片大小
                prediction = torch.max(output, 1)[1].type(torch.LongTensor)
                targets = targets.type(torch.LongTensor)
                data = torch.reshape(data, data.shape[-3:]).type(torch.FloatTensor)


                if is_gpu:
                    pred = prediction.cpu().data.numpy()
                    label = targets.cpu().data.numpy()
                    raw = data.cpu().data.numpy()
                else:
                    pred = prediction.data.numpy()
                    label = targets.data.numpy()
                    raw = data.data.numpy()

                eval_res = []
                for _,  criteria_func in eval_criteria:
                    eval_res.append(criteria_func(np.reshape(label, -1), np.reshape(pred, -1)))

                if idx % 10 == 0:
                    for t, (criteria_name, _) in enumerate(eval_criteria):
                        print("| {}: {:.3} ".format(criteria_name, eval_res[t]), end="")
                    print("|\n")



                    idx += 1

    state_logger("Validate Completed!")
