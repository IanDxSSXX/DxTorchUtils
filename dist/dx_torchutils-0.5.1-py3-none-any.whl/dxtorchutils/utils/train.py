import time
import function
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score
import numpy as np
from .utils import state_logger
from .info_logger import Logger
import random
import torch


class TrainVessel:
    def __init__(
            self,
            dataloader: DataLoader,
            model: torch.nn.Module,
            model_paras_path: str = None,
            opt: torch.optim = None,
            criteria: torch.nn.Module = None,
            epochs: int = 20,
            model_save_path: str = None,
            is_gpu: bool = False,
            eval_func: function = None,
            eval_num: int = 100,
    ):
        """
           训练器
           :param dataloader: 传入的需要训练的dataloader
           :param model: 需要训练的模型
           :param model_paras_path: 训练好的参数的地址，默认为空即重新开始训练
           :param opt: 优化器，默认用Adam
           :param criteria: 损失函数，默认用交叉熵
           :param epochs: 训练循环次数，默认20
           :param model_save_path: 模型保存的地址
           :param is_gpu: 是否使用gpu，默认不使用
           :param eval_func: 每五个epoch，随机取eval_num个来测试已训练的模型，这是模型的测试标准，默认accuracy
           :param eval_num: 每五个epoch，随机取eval_num个来测试已训练的模型，这是选取数量，默认10个
           :return:
        """

        self.logger = Logger("logger/{}".format(time.asctime(time.localtime(time.time()))))
        self.model = model
        self.is_gpu = is_gpu
        self.dataloader = dataloader
        self.epochs = epochs
        self.eval_num = eval_num
        self.model_save_path = model_save_path
        self.eval_func = eval_func

        if model_paras_path is not None:
            self.model.load_state_dict(torch.load(model_paras_path))

        if opt is None:
            self.opt = torch.optim.SGD(model.parameters(), 5e-4, 0.9)

        if criteria is None:
            self.criteria = torch.nn.CrossEntropyLoss()

        if is_gpu:
            self.model = self.model.cuda()

    def train(self):
        state_logger("Model and Dataset Loaded, Start to Train!")

        self.time_start = time.time()
        self.model.train()

        self.idx = 0

        every_epoch = self.dataloader.__len__() % 1000 if self.dataloader.__len__() % 1000 < 10 else 9
        every_epoch = 10 - every_epoch

        for epoch in range(self.epochs):
            for data, targets in self.dataloader:
                self.train_mini_batch(data, targets)

            if (epoch + 1) % every_epoch == 0 or epoch == 0:
                self.model.eval()
                with torch.no_grad():
                    rand = random.randint(0, len(self.dataloader.dataset) - self.eval_num - 1)
                    eval_data, eval_targets = self.dataloader.dataset.__getitem__(slice(rand, rand + self.eval_num))

                    if self.is_gpu:
                        eval_data = eval_data.cuda()
                        eval_targets = eval_targets.cuda()

                    self.loss_all = []
                    self.accuracy_all = []
                    for data, targets in zip(eval_data, eval_targets):
                        data = torch.unsqueeze(data, 0)
                        targets = torch.unsqueeze(targets, 0)

                        # 自定义eval，输入data和targets
                        self.eval_through_training(data, targets)

                    accuracy = np.mean(np.array(self.accuracy_all))
                    loss = np.mean(np.array(self.loss_all))

                    print("Epoch: {:04}/{:04} | Loss: {:.5} | Accuracy: {:.5}".format(epoch + 1, self.epochs, loss,
                                                                                      accuracy))

                    self.logger.log_accuracy(accuracy, loss, epoch)

                    if self.model_save_path is not None:
                        torch.save(self.model.state_dict(), self.model_save_path)

                self.model.train()

            torch.cuda.empty_cache()


        self.logger.add_graph(self.model, next(iter(self.dataloader)))
        self.logger.close()
        state_logger("Training Completed!")

    def train_mini_batch(self, data, targets):
        self.opt.zero_grad()

        if self.is_gpu:
            data = data.cuda()
            targets = targets.cuda()

        output = self.model(data)
        loss = self.criteria(output, targets)
        loss.backward()

        self.opt.step()

        time_end = time.time()
        self.logger.log_training(loss, self.opt.defaults["lr"], time_end - self.time_start, self.idx)
        self.idx += 1

    def eval_through_training(self, data, targets):
        output = self.model(data)
        loss = self.criteria(output, targets)

        if self.is_gpu:
            prediction = np.reshape(torch.max(output, 1)[1].cpu().data.numpy(), -1)
            targets = np.reshape(targets.cpu().data.numpy(), -1)

            loss_num = loss.cpu()
        else:
            prediction = np.reshape(torch.max(output, 1)[1].data.numpy(), -1)
            targets = np.reshape(targets.data.numpy(), -1)

            loss_num = loss

        if self.eval_func is None:
            self.eval_func = accuracy_score

        self.accuracy_all.append(self.eval_func(targets, prediction))
        self.loss_all.append(loss_num)
