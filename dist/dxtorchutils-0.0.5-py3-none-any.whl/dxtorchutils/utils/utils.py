def state_logger(sentence):
    print("┌-----{}-----┐".format("-" * len(sentence)))
    print("|**** {} ****|".format(sentence))
    print("└-----{}-----┘".format("-" * len(sentence)))


