import function
from ..models.UNet import UNet
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score
import numpy as np
from .Others import state_logger
import random


def train(
        dataloader: DataLoader,
        model: torch.nn.Module = None,
        opt: torch.optim = None,
        criteria: torch.nn.Module = None,
        epochs: int = 100,
        gpu: bool = False,
        model_path: str = "model.pth",
        test_working: bool = False,
        eval_func: function = None
):
    if model is None:
        if model_path is None:
            model = UNet()
        else:
            model = torch.load(model_path)

    if opt is None:
        opt = torch.optim.Adam(model.parameters())

    if criteria is None:
        criteria = torch.nn.CrossEntropyLoss()

    if gpu:
        model = model.cuda()

    model.train()

    state_logger("Model and Dataset Loaded, Start to Train!")

    for epoch in range(epochs):
        for idx, (data, target) in enumerate(dataloader):
            if gpu:
                data = data.cuda()
                target = target.cuda()

            output = model(data)
            loss = criteria(output, target)
            loss.backward()
            opt.zero_grad()
            opt.step()

            if test_working:
                break

        if epoch % 5 == 0:
            if eval_func is None:
                model.eval()

                rand = random.randint(0, len(dataloader.dataset[:][0]) - 20)
                test_data = dataloader.dataset[:][0][rand: rand + 10]
                test_target = dataloader.dataset[:][1][rand: rand + 10]

                if gpu:
                    test_data = test_data.cuda()
                    test_target = test_target.cuda()

                test_output = model(test_data)

                loss = criteria(test_output, test_target)

                if gpu:
                    test_prediction = np.reshape(torch.max(test_output, 1)[1].cpu().data.numpy(), -1)
                    test_target = np.reshape(test_target.cpu().data.numpy(), -1)

                    loss_num = loss.cpu().detach()

                else:
                    test_prediction = np.reshape(torch.max(test_output, 1)[1].data.numpy(), -1)
                    test_target = np.reshape(test_target.data.numpy(), -1)

                    loss_num = loss.detach()

                accuracy = accuracy_score(test_target, test_prediction)

                print("Epoch: {:04}/{:04} | Loss: {:.5} | Accuracy: {:.5}".format(epoch, epochs, loss_num, accuracy))

                torch.save(model, model_path)

                model.train()

            else:
                eval_func(model)


    state_logger("Training Completed!")

    return model


