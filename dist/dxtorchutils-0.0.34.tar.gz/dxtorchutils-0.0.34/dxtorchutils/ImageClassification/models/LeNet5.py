"""LeNet 5"""
from collections import OrderedDict
from torch.nn import *


class LeNet5(Module):
    def __init__(self):
        super(LeNet5, self).__init__()
        self.conv0 = _conv_tanh(1, 6)
        self.conv1 = _conv_tanh(6, 16)
        self.conv2 = _conv_tanh(16, 120)
        self.pool0 = AvgPool2d(2)
        self.pool1 = AvgPool2d(2)
        self.fc = _fc_tanh(120, 84)
        self.out = Linear(84, 10)

    def forward(self, x):
        # (n, 1, 32, 32)
        x = self.conv0(x)
        # (n, 6, 28, 28)
        x = self.pool0(x)
        # (n, 6, 14, 14)
        x = self.conv1(x)
        # (n, 16, 10, 10)
        x = self.pool1(x)
        # (n, 16, 5, 5)
        x = self.conv2(x)
        # (n, 120, 1, 1)
        x = x.view(x.shape[0], -1)
        # (n, 120)
        x = self.fc(x)
        # (n, 84)
        output = self.out(x)
        # (n, 10)

        return output


def _conv_tanh(in_channels, out_channels, kernel_size, stride=1, padding=0):
    return Sequential(
        OrderedDict([
            ("conv", Conv2d(in_channels, out_channels, kernel_size, stride, padding)),
            ("activation", Tanh()),
        ])
    )


def _fc_tanh(in_features, out_features):
    return Sequential(
        OrderedDict([
            ("fc", Linear(in_features, out_features)),
            ("activation", Tanh()),
        ])
    )
